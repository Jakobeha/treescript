-- | General-purpose datatypes and helpers.
{-# OPTIONS_GHC -F -pgmF autoexporter #-}
