-- | Converts a @Core@ AST into C code, which can be spliced into a template and compiled.
{-# OPTIONS_GHC -F -pgmF autoexporter #-}
