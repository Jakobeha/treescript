-- | Flat parsing of AST data.
{-# OPTIONS_GHC -F -pgmF autoexporter #-}
