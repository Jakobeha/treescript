-- | More higher-kinded versions of simple types.
module TreeScript.Misc.Ext.Lifted
  ( Void1
  ) where

-- | 'Void' lifted.
data Void1 a
