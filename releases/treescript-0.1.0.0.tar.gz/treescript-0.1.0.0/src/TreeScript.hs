-- | Full API for compiling and analysing TreeScript programs.
{-# OPTIONS_GHC -F -pgmF autoexporter #-}
